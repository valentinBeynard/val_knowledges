'''
Created on 29 juil. 2023

@author: valbe
'''

class CTService():
    '''
    classdocs
    '''


    def __init__(self, m_name):
        
        self.name = m_name
        
        self.state_list = {'DEFAULT_IDDLE'}
        self.state = 'DEFAULT_IDDLE'
        
    def setup(self):
        return
    
    
    def run(self):
        return 0
        