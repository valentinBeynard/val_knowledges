from distutils.core import setup

setup(name='CoreTrigger',
      version='0.1',
      description='Python Mini Server parsing HTTP request',
      author='Valentin Beynard',
      author_email='valentin.beynard@watlow.com',
      #packages=['gpiozero'],
     )